from distutils.core import setup
 
setup(name = "elasticsandra",
      version = "0.1",
      description = "Synchronizer between Elasticsearch <-> Cassandra",
      author = "Robson Koji",
      author_email = "rbsnkjmr@gmail.com",
      url = "https://github.com/fortinbras/elasticsandra/",
#      packages=["elasticsandra.elasticsearch", "elasticsandra.cassandra"]
      packages=["elasticsandra"]
      )



